var CreateMultiChart=function(data,canvas_id)
{
    labels          =   []
    datasets        =   []
    backgroundColor =   []   
    borderColor     =   ["#0AD149","#0866D1"]            
    i=0
    for (d in data){
        console.log('d: ',d,'data[d]: ',data[d]);
        if (d=='Date')
        {
            labels = data[d];
        }
        else
        {
            datasets.push({
                label: d,
                backgroundColor:backgroundColor[i],
                borderColor:borderColor[i],
                data: data[d],
                borderWidth: 2,
            });
            i++;
        }
    }

    if (canvas_id==undefined)
        canvas_id="multichart";
    var ctx = $('#'+canvas_id);

    var multiChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            color:"#D8D9DA",
            datasets:datasets
        },
        options: {
            responsive: true,
             legend: {
               labels: {
                    fontColor: "#D8D9DA",
                    fontSize: 10,
                    useLineStyle: true,
                    padding : 10
                }
            },
            tooltips: {
    					mode: 'index',
    					intersect: false,
                        callbacks: {
                            label: function(tooltipItem, data) {
                                var value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                                value = value.toString();
                                value = value.split(/(?=(?:...)*$)/);
                                value = value.join(',');
                                return value;
                            }
                        },
    				},
    	    hover: {
    					mode: 'nearest',
    					intersect: true
    				},
            scales: {
                yAxes: [{
                    stacked: true,
                    ticks: {
                    fontColor: "white",
                        beginAtZero:true
                    },
                    gridLines: { color: "#464648" },
                    scaleLabel: {                           
                            display: true,
                            labelString : 'Deals',
                            fontColor   : 'white',
                            fontSize    : "15",
                            fontStyle   : "550",
                          }                                 
                }],
                xAxes:[{
                    ticks:{
                    fontColor: "#D8D9DA",          
                        autoSkip: true                 
                    },
                    gridLines: { color: "#464648" },
                    scaleLabel: {                          
                            display: true,
                            labelString : 'Date',
                            fontColor   : 'white',
                            fontSize    : "15",
                            fontStyle   : "550",
                          }                                
                }]
            },
        }
    });

}