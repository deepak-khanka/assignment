var LabelFormatter = function (context) {
    if (context.section == 'outer') {
        if (context.part == 'percentage')
            return 'Deals, '+context.value+', '+context.label+'%';
    }
};
var CreatePiechart=function(data,div)
{

    var datasets= [ 
            { label: "Activations", value:  data[0],color:"#3D9CE0" },
            { label: "Fulfillments", value:  data[1],color:"#E08719" },
    ]
    pie = new d3pie(div, {
            data:{
              "sortOrder": "value-desc",
              "content": datasets,
            },

            "size": {
                    "canvasHeight":240,
                    "canvasWidth": 350,
                    "pieOuterRadius": "70%",
            },
            "labels": {
                "formatter" : LabelFormatter,
                "percentage": {
                     "color": "#fff",
                     "decimalPlaces": 1
                },
                "outer": {
                    "format": "percentage",
                    "color": "#fff",
                    "pieDistance": 0
                },
                "inner": {
                    "hideWhenLessThanPercentage": 1
                },

                "mainLabel": {
                "color": "#fff",
                "font": "custom_font",
                "fontSize": 12
                },
                "lines": {
                    "enabled": false,
                    "color": "#fff"
                },
                "value": {
                    "color": "#fff",
                    "fontSize": 12  ,
                    "font": "times new roman"
                },
                "truncation": {
                    "enabled": true
              }
            },
            "effects": {
            "pullOutSegmentOnClick": {
                "effect": "linear",
                "speed": 400,
                "size": 8
            }
            },
            "tooltips": {
                "enabled": true,
                "type": "placeholder",
                "string": "{label} : {percentage}% ({value})",
                "styles": {
                    "borderRadius": 3,
                },
            },
       });
    var svg         =   d3.select('#'+pie.element.id).select("svg");
    var contents    =   pie.options.data.content;
    var x_arr       =   [35,195]; 
    var y_arr       =   [225,225]; 
    for(var c in contents)
    {
        var color=  contents[c].color;
        var text = 'No. of '+contents[c].label;
         svg.append("svg:rect")
        .attr("x", x_arr[c])
        .attr("y", y_arr[c])
        .attr("width", 10)
        .attr("height", 10)
        .style("fill", color);      
        svg.append("text")
        .attr("x", x_arr[c]+20)
        .attr("y", y_arr[c]+8)
        .attr("style", 'font-size: 10px; font-family: sans-serif; fill:#fff; font-weight: bold;')
        .text(text);   
           
    }
}


