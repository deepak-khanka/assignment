// global variable declaration
var data_dict = new Object;

$(document).ready(function(e){

	// getting of datatable tr element as object
	var tble_tr = $('#dt').find('tr');

	// setting of column headers in datatable
	for(var col_header in data_dict)
		tble_tr.append('<th><strong>'+col_header+'</strong></th>');

	// initilisation of datatable
	var dtbl = $('#dt').DataTable({
		"scrollY" 		:   250,
		"scrollCollapse": 	true,
		"jQueryUI" 		:   true,
		"ordering" 		: 	true,
		"paging" 		: 	false,
		"aaSorting" 	: 	[]
	});

// inserting the rows with corresponding data into the datatable
	for(var i in all_data_arr[0])
	{
		var row = dtbl.row.add( [
			all_data_arr[0][i],
			all_data_arr[1][i],
			all_data_arr[2][i],
		]).draw( false );		
	}

	// creating the multi-line chart
	CreateMultiChart(data_dict, "multichart");

	// calculating the total deals of activations
	var activations=0;
	for(var v in all_data_arr[1])
		activations+=parseInt(all_data_arr[1][v]);

	// calculating the total deals of fulfillments
	var fulfillments=0;
	for(var v in all_data_arr[2])
		fulfillments+=parseInt(all_data_arr[2][v]);	

	// creating the pie-chart
	CreatePiechart([activations,fulfillments], "piechart");
});