from django.urls import path
from django.conf.urls import url
from display import views

app_name = 'display'
urlpatterns = [

    url(r'^charts/', views.Charts.as_view(), name='charts'),
]
