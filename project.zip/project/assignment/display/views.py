from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import TemplateView
import pandas as pd
from django.conf import settings
from os import path
from collections import OrderedDict 
import logging
logger = logging.getLogger(__name__)



# TemplateView class to handle the request
class Charts(TemplateView):
	# initlization of variables
	template_name 	= 	'display/charts.html' 												#	template name
	context 		=	{'status': False} 	 												# 	on failure template will send this context
	# CHANGE raw_data.csv TO YOUR RAW DATA FILENAME
	rawdata_path 	=	path.abspath(path.join(settings.BASE_DIR ,"../raw_data.csv"))  		#	csv file path. it's outside of project directory in this case. filename : raw_data.csv
	column_headers 	=	['Date','No. of Activations','No. of Fulfillments'] 				#	setting of column headers same as in csv file

# only get rquest method allowed
	def get(self,request):
		try:
			self.context['data']	=	self.raw_data()
			self.context['status']	=	True
		except Exception as e:
			logger.debug('Charts().get() Error: ',e) 										#	in case of error the error statemnents can be found in debug.log
		return render(request, self.template_name,self.context) 

# function to fetch the csv file for raw data and populting a dict of array which will be send through template as context
	def raw_data(self):	
		data_dict= OrderedDict()
		try:
			obj_csv = pd.read_csv(self.rawdata_path,delimiter=',') 							# 	reading  the csv file 
			c = self.column_headers
			data_arr0 =  []
			data_arr1 =  []
			data_arr2 =  []
			for i,p in obj_csv.iterrows(): 													# 	iterating rows
				data_arr0.append(p[c[0]])
				data_arr1.append(p[c[1]])
				data_arr2.append(p[c[2]])
			data_dict[c[0]]=data_arr0	
			data_dict[c[1]]=data_arr1
			data_dict[c[2]]=data_arr2
		except Exception as e:
			logger.debug('Charts().raw_data() Error: ',e)	
		return data_dict	
